$(document).ready(function() {  
 $("input").css("background-color", "cyan");  
 });